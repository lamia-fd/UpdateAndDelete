package com.example.postrequests

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.telecom.Call
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    var newUser = ArrayList<String>()
   lateinit var myRv:RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var button=findViewById<Button>(R.id.button2)
        var deleteUpdate=findViewById<Button>(R.id.button3)

        deleteUpdate.setOnClickListener {
            intent = Intent(applicationContext, UpdateAndDelete::class.java)
            startActivity(intent)
        }

        var text=findViewById<TextView>(R.id.textView2)

        button.setOnClickListener {
            intent = Intent(applicationContext, MainActivity2::class.java)
            startActivity(intent)
        }


        val apiInterface = APIClient().getClient()?.create(APIInterface::class.java)

        if (apiInterface != null) {
            apiInterface.doGetListResources()?.enqueue(object :Callback<List<Users.UserDetails>> {
                override fun onResponse(
                    call: retrofit2.Call<List<Users.UserDetails>>,
                    response: Response<List<Users.UserDetails>>
                ) {

                    var stringToBePritined:String? = "";
                    for(User in response.body()!!){
                        stringToBePritined = stringToBePritined +User.name+ "\n"+User.location + "\n"+"\n"
                        text.text=stringToBePritined

                    }

                }
                override fun onFailure(call: retrofit2.Call<List<Users.UserDetails>>, t: Throwable) {

                }
            })
        }








    }

}

