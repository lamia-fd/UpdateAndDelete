package com.example.postrequests

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import retrofit2.*

class UpdateAndDelete : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_updat_and_delete)



        val idText=findViewById<EditText>(R.id.idText)
        val nameText=findViewById<EditText>(R.id.nameText)
        val locationText=findViewById<EditText>(R.id.locationText)
        val updateButton=findViewById<Button>(R.id.Update)
        val deleteButton=findViewById<Button>(R.id.Delete)



       val apiInterface = APIClient().getClient()?.create(APIInterface::class.java)


        updateButton.setOnClickListener {
            apiInterface?.updateUser(idText.text.toString().toInt(), Users.UserDetails(nameText.text.toString(), locationText.text.toString(),idText.text.toString().toInt()))
                ?.enqueue(
                    object : Callback<Users.UserDetails> {
                        override fun onResponse(
                            call: Call<Users.UserDetails>,
                            response: Response<Users.UserDetails>
                        ) {
                            Toast.makeText(applicationContext, "updated", Toast.LENGTH_LONG).show()
                        }

                        override fun onFailure(call: Call<Users.UserDetails>, t: Throwable) {
                            Toast.makeText(applicationContext, "failed", Toast.LENGTH_LONG).show()
                        }

                    }
                )
        }


        deleteButton.setOnClickListener {
           apiInterface?.deleteUser(idText.text.toString().toInt())?.enqueue(object: Callback<Void> {

               override fun onResponse(call: Call<Void>, response: Response<Void>) {
                   Toast.makeText(applicationContext, "Deleted", Toast.LENGTH_LONG).show()               }

               override fun onFailure(call: Call<Void>, t: Throwable) {
                   Toast.makeText(applicationContext, "failed", Toast.LENGTH_LONG).show()               }

           })

        }


    }
}