package com.example.postrequests

import retrofit2.*
import retrofit2.http.*




interface APIInterface {


    @Headers("Content-Type: application/json")

    @GET("/test/")
    fun doGetListResources(): Call<List<Users.UserDetails>>


    @Headers("Content-Type: application/json")
    @POST("/test/")
    fun addUser(@Body userData: Users.UserDetails): Call<Users.UserDetails>

    @Headers("Content-Type: application/json")
    @PUT("/test/{pk}")
    fun updateUser(@Path("pk")id: Int,@Body userData:Users.UserDetails):retrofit2.Call<Users.UserDetails>

    @Headers("Content-Type: application/json")
    @DELETE("/test/{pk}")
    fun deleteUser(@Path("pk") id: Int ): Call<Void>


}