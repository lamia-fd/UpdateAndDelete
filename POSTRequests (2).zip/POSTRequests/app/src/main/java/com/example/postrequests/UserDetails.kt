package com.example.postrequests

import com.google.gson.annotations.SerializedName

class Users {




    class UserDetails(
        @SerializedName("name") var name: String?,
        @SerializedName("location") var location: String?,
        pk: Int
    ) {

        @SerializedName("pk")
        var pk: Int? = pk


    }

}